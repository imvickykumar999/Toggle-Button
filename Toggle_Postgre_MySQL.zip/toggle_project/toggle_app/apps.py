from django.apps import AppConfig


class ToggleAppConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'toggle_app'

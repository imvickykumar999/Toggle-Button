SELECT id, name, is_active
	FROM public.toggle_app_toggleitem;